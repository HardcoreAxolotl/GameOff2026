// Feather disable all

/// Sets rebinding state for a device. The device will be scanned for all input. Discovered
/// bindings can be returned by calling `InputDeviceGetRebindingResult()`. Only gamepads and
/// keyboard and mouse (`INPUT_KBM`) devices can be scanned. Bindings to explicitly ignore and
/// allow can be set up by passing arrays into the optional `ignoreArray` and `allowArray`
/// parameters.
/// 
/// N.B. Input from a device that is being scanned will continue as normal. To prevent input
///      leaking to e.g. interface navigation you should be careful to check against
///      `InputDeviceGetRebinding()` where appropriate.
/// 
/// @param {Real} device
/// @param {Bool} state
/// @param {Array<Enum.INPUT_VERB,Real>} [ignoreArray]
/// @param {Array<Enum.INPUT_VERB,Real>} [allowArray]
/// @param {Bool} [consume=true]

function InputDeviceSetRebinding(_device, _state, _ignoreArray = undefined, _allowArray = undefined, _consume = true)
{
    static _rebindingMap   = __InputSystem().__rebindingMap;
    static _rebindingArray = __InputSystem().__rebindingArray;
    static _playerArray    = __InputSystemPlayerArray();
    static _verbCount      = __InputSystem().__verbCount;
    
    static _funcConsumeAll = function(_playerIndex)
    {
        static _playerArray = __InputSystemPlayerArray();
        static _verbCount   = __InputSystem().__verbCount;
        
        if ((not is_numeric(_playerIndex)) || (_playerIndex < 0) || (_playerIndex >= INPUT_MAX_PLAYERS))
        {
            return;
        }
        
        var _playerStruct = _playerArray[_playerIndex];
        var _i = 0;
        repeat(_verbCount)
        {
            __InputVerbConsumeInternal(_playerStruct, _i, true);
            ++_i;
        }
    }
    
    if ((_device != INPUT_KBM) && (_device < 0))
    {
        return;
    }
    
    if (_state)
    {
        if (not ds_map_exists(_rebindingMap, _device))
        {
            var _handler = new __InputClassRebindingHandler(_device, _ignoreArray, _allowArray);
            _rebindingMap[? _device] = _handler;
            array_push(_rebindingArray, _handler);
            
            if (_consume)
            {
                _funcConsumeAll(InputDeviceGetPlayer(_device));
            }
        }
    }
    else
    {
        if (ds_map_exists(_rebindingMap, _device))
        {
            ds_map_delete(_rebindingMap, _device);
            
            var _i = 0;
            repeat(array_length(_rebindingArray))
            {
                if (_rebindingArray[_i].__device == _device)
                {
                    array_delete(_rebindingArray, _i, 1);
                }
                else
                {
                    ++_i;
                }
            }
            
            if (_consume)
            {
                _funcConsumeAll(InputDeviceGetPlayer(_device));
            }
        }
    }
}
