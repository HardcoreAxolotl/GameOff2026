// Feather disable all

/// Defines a verb cluster. Clusters are used for cluster checks such as `InputX()` and
/// `InputDirection()`.
/// 
/// The optional `axisBiasFactor` parameter allows you to bias the cluster along straight lines
/// along the x and y axes. This makes it easier for the player to input exactly horizontal and
/// exactly vertical movement. The value for this parameter should be from 0 to 1. Higher values
/// make the biasing behaviour stronger. The default value for `axisBiasFactor` is 0 which confers
/// no axis bias whatsoever.
///
/// `axisBiasDiagonals` controls whether the axis bias should also allow diagonal inputs. It
/// defaults to `false`: biasing will not select diagonal directions. Setting this parameter to
/// `true` will allow diagonal directions.
/// 
/// @param {Enum.INPUT_CLUSTER,Real} clusterIndex
/// @param {Enum.INPUT_VERB,Real} verbUp
/// @param {Enum.INPUT_VERB,Real} verbRight
/// @param {Enum.INPUT_VERB,Real} verbDown
/// @param {Enum.INPUT_VERB,Real} verbLeft
/// @param {Real} [axisBiasFactor=0]
/// @param {Real} [axisBiasDiagonals=false]
/// @param {Any} [metadata=struct]

function InputDefineCluster(_clusterIndex, _verbUp, _verbRight, _verbDown, _verbLeft, _axisBiasFactor = 0, _axisBiasDiagonals = false, _metadata = {})
{
    static _system = __InputSystem();
    
    if (GM_build_type == "run")
    {
        if not (_system.__verbDefineAllowed)
        {
            __InputError("InputDefineCluster() must only be called in __InputConfigVerbs()");
        }
    }
    
    with(_system)
    {
        var _definition = new __InputClassClusterDefinition(_clusterIndex, _verbUp, _verbRight, _verbDown, _verbLeft, _axisBiasFactor, _axisBiasDiagonals, _metadata);
        __clusterDefinitionArray[@ _clusterIndex] = _definition;
        
        //Keep track of what clusters a verb to assigned to
        var _func = function(_clusterIndex, _verb)
        {
            var _verbToClusterArray = __verbToClusterMap[? _verb];
            if (is_array(_verbToClusterArray))
            {
                array_push(_verbToClusterArray, _clusterIndex);
            }
            else
            {
                _verbToClusterArray = [_clusterIndex];
                __verbToClusterMap[? _verb] = _verbToClusterArray;
            }
            
        }
        
        _func(_clusterIndex, _verbUp);
        _func(_clusterIndex, _verbRight);
        _func(_clusterIndex, _verbDown);
        _func(_clusterIndex, _verbLeft);
    }
}