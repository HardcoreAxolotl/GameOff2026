image_speed = 0;
in_button = false;
enabled = false;