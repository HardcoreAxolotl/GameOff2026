// Properties
duration = 60;
targetRoom = room;
color = c_white;
above_gui = false;

// Vars
timer = 0;
alpha = 0;
state =  true;