layer_set_visible("PauseMenu", false);
layer_set_visible("StartMenu", false);
layer_set_visible("SettingsMenu", false);